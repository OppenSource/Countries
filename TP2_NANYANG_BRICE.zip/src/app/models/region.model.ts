export interface Region {
  nom: string;
}
