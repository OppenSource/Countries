// country.model.ts
export interface Country {
  nom: string;
  population: number;
  image: string;
  capitale: string;
}
