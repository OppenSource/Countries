export interface SousRegion {
  subregion: string;
}
